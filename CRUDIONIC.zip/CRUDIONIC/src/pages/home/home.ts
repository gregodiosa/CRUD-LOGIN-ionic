import { Component } from '@angular/core';
import { IonicPage, NavController, AlertController } from 'ionic-angular';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
//import { Observable } from 'rxjs';

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  PNombre;
  PPrecio;
  PDesc;

  producto: Observable<any[]>;


  constructor(
    public navCtrl: NavController,
    public alertCtrl: AlertController,
    public database: AngularFireDatabase
  ) {

      this.producto = this.database.list("Productos");/*.snapshotChanges()
      .map(changes => {
      return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
    });*/

    }

  Agregar(){
    this.database.list("Productos").push({
      nombre: this.PNombre,
      precio: this.PPrecio,
      descri : this.PDesc
    });
  }

 Actualizar(producto) {
    const confirm = this.alertCtrl.create({
      title: 'Actualizar Registro',
      inputs: [
        {
          name: 'nombre',
          placeholder: 'nombre',
          value : producto.nombre
        },
        {
          name: 'precio',
          placeholder: 'precio',
          value : producto.precio
        },
        {
          name: 'Descri',
          placeholder: 'Descripcion',
          value : producto.descri
        }
      ],


      buttons: [
        {
          text: 'Aceptar',
          handler: data => {
            console.log('Click Aceptar');
            this.database.list("Productos").update( producto.key,{
                nombre: data.nombre,
                precio: data.precio,
                descri: data.Descri
              });
          }
        },
        {
          text: 'Cancelar',
          handler: () => {
            console.log('Click Cancelar');
          }
        }
      ]
    });
     confirm.present();
  }

  Editar( producto ){

  }

 Eliminar(producto) {
    const confirm = this.alertCtrl.create({
      title: '¿Elimar Registro?',

      buttons: [
        {
          text: 'Aceptar',
          handler: () => {
            console.log('Click Aceptar');
           this.DelProducto(producto);
          }
        },
        {
          text: 'Cancelar',
          handler: () => {
            console.log('Click Cancelar');
          }
        }
      ]
    });
     confirm.present();
  }

  DelProducto( producto ){
    console.log( producto );
    this.database.list("Productos").remove();
  }


}
